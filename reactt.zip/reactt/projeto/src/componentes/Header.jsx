function Header(){
    return(
        <header>
            <h1>Atividade</h1>
        </header>
    )
}

export default Header