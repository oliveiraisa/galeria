function Sobre(){
    return(

        <section>
            <h2>Billie</h2>
            <p>diva</p>
        </section>
    )
}
export default Sobre;