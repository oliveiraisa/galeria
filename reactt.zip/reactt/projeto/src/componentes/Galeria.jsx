import img from '../../public/billie.avif'

export default function Galeria() {
    return(
       <>
       <section className='imagem1'>
            <img src={img}/>
            <img src={img}/>
            <img src={img}/>
       </section>
      
       </>
    )
}

