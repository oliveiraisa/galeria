export default function Banner(){
    return(
        <section classNome="Banner">
        
        </section>
    )
}