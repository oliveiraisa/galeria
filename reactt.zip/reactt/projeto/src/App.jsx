import './App.css'
import Banner from './componentes/Banner'
import Header from './componentes/Header'
import Sobre from './componentes/Sobre'
import Galeria from './componentes/Galeria'
function App() {

  return (
    <div>
      <Header/>
      <Banner/>
      <Sobre/>
      <Galeria/>

    </div>
  )
}

export default App