export default function Banner(){
    return(
        <section>
            <h1>aaaaa</h1>
            <img src="./billie.avif" alt="" />
        </section>
    )
}